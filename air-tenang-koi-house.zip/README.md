# Air Tenang Koi House

Website toko online ikan koi, dibangun dengan React + Vite.

## Menjalankan di komputer sendiri

```bash
npm install
npm run dev
```

Lalu buka `http://localhost:5173`.

## Build untuk produksi

```bash
npm run build
```

Hasilnya ada di folder `dist/`.

## Catatan

- Data produk & keranjang disimpan di `localStorage` browser pengunjung (bertahan
  walau browser ditutup, tapi berbeda-beda per pengunjung/per perangkat).
- Ganti nomor WhatsApp di `src/App.jsx` (cari teks `6281234567890`) dengan nomor toko asli.
- Ganti alamat & jam buka di bagian `<footer>` pada `src/App.jsx`.
