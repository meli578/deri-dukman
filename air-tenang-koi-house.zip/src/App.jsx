import { useState, useEffect, useRef, useMemo } from "react";

// ---------- Helpers ----------
const RUPIAH = (n) =>
  "Rp " + Number(n).toLocaleString("id-ID");

const VARIETAS = ["Kohaku", "Showa", "Sanke", "Shiro Utsuri", "Asagi", "Tancho", "Ogon", "Butterfly"];

const SEED_PRODUCTS = [
  {
    id: "k-001",
    nama: "Kohaku Premium",
    varietas: "Kohaku",
    ukuran: 35,
    umur: "1.5 tahun",
    harga: 2500000,
    stok: 3,
    deskripsi:
      "Pola merah di atas putih bersih, body bulat dan seimbang. Indukan asal Niigata, sudah lolos seleksi 3 tahap.",
    warna: "#D94F30",
  },
  {
    id: "k-002",
    nama: "Showa Sanshoku",
    varietas: "Showa",
    ukuran: 42,
    umur: "2 tahun",
    harga: 4200000,
    stok: 2,
    deskripsi:
      "Tiga warna kontras: hitam pekat, merah berani, putih cerah. Sumi (hitam) menyebar rata dari kepala ke ekor.",
    warna: "#1a1a1a",
  },
  {
    id: "k-003",
    nama: "Taisho Sanke",
    varietas: "Sanke",
    ukuran: 30,
    umur: "1 tahun",
    harga: 1800000,
    stok: 5,
    deskripsi:
      "Dasar putih dengan tumpukan merah dan bintik hitam kecil yang rapi. Cocok untuk kolam rumahan.",
    warna: "#D94F30",
  },
  {
    id: "k-004",
    nama: "Shiro Utsuri",
    varietas: "Shiro Utsuri",
    ukuran: 38,
    umur: "1.5 tahun",
    harga: 2100000,
    stok: 4,
    deskripsi:
      "Hitam dasar dengan corak putih tegas menyerupai petir. Karakter tenang, makan agresif.",
    warna: "#1a1a1a",
  },
  {
    id: "k-005",
    nama: "Asagi Klasik",
    varietas: "Asagi",
    ukuran: 33,
    umur: "1.2 tahun",
    harga: 1500000,
    stok: 6,
    deskripsi:
      "Sisik biru muda tersusun rapi seperti jaring di punggung, dengan perut dan sirip kemerahan.",
    warna: "#5b8fa3",
  },
  {
    id: "k-006",
    nama: "Tancho Kohaku",
    varietas: "Tancho",
    ukuran: 28,
    umur: "10 bulan",
    harga: 3200000,
    stok: 2,
    deskripsi:
      "Satu titik merah bulat sempurna di kepala, badan putih bersih tanpa cela. Koleksi langka.",
    warna: "#D94F30",
  },
];

// ---------- Decorative SVG: koi silhouette ----------
function KoiSilhouette({ className, style }) {
  return (
    <svg viewBox="0 0 200 90" className={className} style={style} aria-hidden="true">
      <path
        d="M10,45 C20,20 55,8 95,10 C130,12 150,22 175,30 C168,34 160,36 155,45 C160,54 168,56 175,60 C150,68 130,78 95,80 C55,82 20,70 10,45 Z"
        fill="currentColor"
      />
      <path d="M178,28 L196,18 L188,30 L196,42 L178,32 Z" fill="currentColor" opacity="0.85" />
    </svg>
  );
}

function RippleBackdrop() {
  return (
    <svg className="ripple-svg" viewBox="0 0 1200 500" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <radialGradient id="rg1" cx="30%" cy="35%" r="60%">
          <stop offset="0%" stopColor="#cfe7e1" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#cfe7e1" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="1200" height="500" fill="url(#rg1)" />
      {[0, 1, 2, 3, 4].map((i) => (
        <circle
          key={i}
          cx={220 + i * 14}
          cy={160 + i * 6}
          r={30 + i * 38}
          fill="none"
          stroke="#1B7A75"
          strokeOpacity={0.16 - i * 0.022}
          strokeWidth="1.5"
        />
      ))}
      {[0, 1, 2, 3].map((i) => (
        <circle
          key={"b" + i}
          cx={980 - i * 10}
          cy={340 + i * 4}
          r={22 + i * 30}
          fill="none"
          stroke="#1B7A75"
          strokeOpacity={0.13 - i * 0.02}
          strokeWidth="1.2"
        />
      ))}
    </svg>
  );
}

// ---------- Main App ----------
export default function KoiShop() {
  const [products, setProducts] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [page, setPage] = useState("home"); // home | catalog | cart
  const [filterVarietas, setFilterVarietas] = useState("Semua");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("terbaru");
  const [selected, setSelected] = useState(null); // product detail modal
  const [cart, setCart] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [toast, setToast] = useState(null);
  const scrollRef = useRef(null);

  // ---- Load from localStorage ----
  useEffect(() => {
    try {
      const saved = localStorage.getItem("koi-products");
      if (saved) {
        setProducts(JSON.parse(saved));
      } else {
        setProducts(SEED_PRODUCTS);
        localStorage.setItem("koi-products", JSON.stringify(SEED_PRODUCTS));
      }
    } catch (e) {
      setProducts(SEED_PRODUCTS);
    }
    try {
      const savedCart = localStorage.getItem("koi-cart");
      if (savedCart) setCart(JSON.parse(savedCart));
    } catch (e) {
      // no cart yet
    }
    setLoaded(true);
  }, []);

  const persistProducts = (next) => {
    setProducts(next);
    try {
      localStorage.setItem("koi-products", JSON.stringify(next));
    } catch (e) {
      showToast("Gagal menyimpan data produk.");
    }
  };

  const persistCart = (next) => {
    setCart(next);
    try {
      localStorage.setItem("koi-cart", JSON.stringify(next));
    } catch (e) {
      showToast("Gagal menyimpan keranjang.");
    }
  };

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2600);
  };

  const addToCart = (product) => {
    const existing = cart.find((c) => c.id === product.id);
    let next;
    if (existing) {
      next = cart.map((c) =>
        c.id === product.id ? { ...c, qty: Math.min(c.qty + 1, product.stok) } : c
      );
    } else {
      next = [...cart, { id: product.id, qty: 1 }];
    }
    persistCart(next);
    showToast(`${product.nama} ditambahkan ke keranjang`);
  };

  const removeFromCart = (id) => {
    persistCart(cart.filter((c) => c.id !== id));
  };

  const updateQty = (id, qty) => {
    const product = products.find((p) => p.id === id);
    const clamped = Math.max(1, Math.min(qty, product ? product.stok : 99));
    persistCart(cart.map((c) => (c.id === id ? { ...c, qty: clamped } : c)));
  };

  const cartDetailed = useMemo(() => {
    return cart
      .map((c) => {
        const p = products.find((pp) => pp.id === c.id);
        return p ? { ...p, qty: c.qty } : null;
      })
      .filter(Boolean);
  }, [cart, products]);

  const cartTotal = cartDetailed.reduce((sum, c) => sum + c.harga * c.qty, 0);
  const cartCount = cartDetailed.reduce((sum, c) => sum + c.qty, 0);

  const filteredProducts = useMemo(() => {
    let list = [...products];
    if (filterVarietas !== "Semua") list = list.filter((p) => p.varietas === filterVarietas);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (p) => p.nama.toLowerCase().includes(q) || p.varietas.toLowerCase().includes(q)
      );
    }
    if (sort === "harga-asc") list.sort((a, b) => a.harga - b.harga);
    if (sort === "harga-desc") list.sort((a, b) => b.harga - a.harga);
    if (sort === "ukuran-desc") list.sort((a, b) => b.ukuran - a.ukuran);
    return list;
  }, [products, filterVarietas, search, sort]);

  const goTo = (p) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (!loaded) {
    return (
      <div className="boot-screen">
        <KoiSilhouette className="boot-koi" />
        <div>Menyiapkan kolam…</div>
        <style>{baseStyles}</style>
      </div>
    );
  }

  return (
    <div className="app-root">
      <style>{baseStyles}</style>

      {/* ---------- NAV ---------- */}
      <header className="nav">
        <button className="brand" onClick={() => goTo("home")}>
          <KoiSilhouette className="brand-icon" />
          <span>
            Air Tenang <small>koi house</small>
          </span>
        </button>
        <nav className="nav-links">
          <button className={page === "home" ? "active" : ""} onClick={() => goTo("home")}>
            Beranda
          </button>
          <button className={page === "catalog" ? "active" : ""} onClick={() => goTo("catalog")}>
            Katalog
          </button>
          <button className="cart-btn" onClick={() => goTo("cart")}>
            Keranjang
            {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
          </button>
        </nav>
      </header>

      {/* ---------- HOME ---------- */}
      {page === "home" && (
        <main>
          <section className="hero">
            <RippleBackdrop />
            <KoiSilhouette className="hero-koi hero-koi-1" />
            <KoiSilhouette className="hero-koi hero-koi-2" />
            <div className="hero-content">
              <span className="eyebrow">Sejak kolam pertama, 2014</span>
              <h1>
                Air tenang,
                <br />
                koi terbaik.
              </h1>
              <p>
                Koi pilihan langsung dari peternak Niigata &amp; Blitar — diseleksi dari bentuk
                badan, ketajaman pola, dan ketahanan, sebelum sampai ke kolam Anda.
              </p>
              <div className="hero-actions">
                <button className="btn-primary" onClick={() => goTo("catalog")}>
                  Lihat katalog
                </button>
                <a className="btn-ghost" href="#cara-pesan">
                  Cara memesan
                </a>
              </div>
            </div>
          </section>

          <section className="strip">
            {[
              ["6+", "varietas koi tersedia"],
              ["100%", "karantina sebelum kirim"],
              ["24", "jam respons WhatsApp"],
            ].map(([num, label]) => (
              <div key={label} className="strip-item">
                <strong>{num}</strong>
                <span>{label}</span>
              </div>
            ))}
          </section>

          <section className="featured">
            <div className="section-head">
              <h2>Koi unggulan minggu ini</h2>
              <button className="link-btn" onClick={() => goTo("catalog")}>
                Semua koi →
              </button>
            </div>
            <div className="card-grid">
              {products.slice(0, 3).map((p) => (
                <ProductCard key={p.id} p={p} onOpen={() => setSelected(p)} onAdd={() => addToCart(p)} />
              ))}
            </div>
          </section>

          <section id="cara-pesan" className="how">
            <h2>Cara memesan</h2>
            <ol>
              <li>
                <span className="how-mark">Pilih</span>
                Telusuri katalog, lihat detail ukuran dan pola tiap koi.
              </li>
              <li>
                <span className="how-mark">Masukkan</span>
                Tambahkan koi pilihan ke keranjang, atur jumlahnya.
              </li>
              <li>
                <span className="how-mark">Konfirmasi</span>
                Kirim pesanan lewat WhatsApp, kami balas dengan rincian ongkir &amp; packing.
              </li>
            </ol>
          </section>
        </main>
      )}

      {/* ---------- CATALOG ---------- */}
      {page === "catalog" && (
        <main className="catalog-page">
          <div className="catalog-head">
            <h1>Katalog koi</h1>
            <p>{filteredProducts.length} ekor tersedia sesuai filter</p>
          </div>

          <div className="catalog-toolbar">
            <input
              type="text"
              placeholder="Cari nama atau varietas…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="search-input"
            />
            <select value={filterVarietas} onChange={(e) => setFilterVarietas(e.target.value)}>
              <option>Semua</option>
              {VARIETAS.map((v) => (
                <option key={v}>{v}</option>
              ))}
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value)}>
              <option value="terbaru">Terbaru</option>
              <option value="harga-asc">Harga: rendah → tinggi</option>
              <option value="harga-desc">Harga: tinggi → rendah</option>
              <option value="ukuran-desc">Ukuran terbesar</option>
            </select>
            <button className="btn-primary small" onClick={() => setShowAddForm(true)}>
              + Tambah produk
            </button>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="empty-state">
              <KoiSilhouette className="empty-koi" />
              <h3>Belum ada koi yang cocok</h3>
              <p>Coba ubah kata pencarian atau pilih varietas lain.</p>
            </div>
          ) : (
            <div className="card-grid">
              {filteredProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  p={p}
                  onOpen={() => setSelected(p)}
                  onAdd={() => addToCart(p)}
                  onDelete={() => {
                    if (confirm(`Hapus "${p.nama}" dari katalog?`)) {
                      persistProducts(products.filter((pp) => pp.id !== p.id));
                      showToast(`${p.nama} dihapus dari katalog`);
                    }
                  }}
                  editable
                />
              ))}
            </div>
          )}
        </main>
      )}

      {/* ---------- CART ---------- */}
      {page === "cart" && (
        <main className="cart-page">
          <h1>Keranjang pesanan</h1>
          {cartDetailed.length === 0 ? (
            <div className="empty-state">
              <KoiSilhouette className="empty-koi" />
              <h3>Keranjang masih kosong</h3>
              <p>Pilih koi dari katalog untuk mulai memesan.</p>
              <button className="btn-primary" onClick={() => goTo("catalog")}>
                Buka katalog
              </button>
            </div>
          ) : (
            <>
              <ul className="cart-list">
                {cartDetailed.map((c) => (
                  <li key={c.id} className="cart-row">
                    <div className="cart-row-koi" style={{ color: c.warna }}>
                      <KoiSilhouette className="cart-koi-icon" />
                    </div>
                    <div className="cart-row-info">
                      <strong>{c.nama}</strong>
                      <span>
                        {c.varietas} · {c.ukuran} cm
                      </span>
                    </div>
                    <div className="cart-row-qty">
                      <button onClick={() => updateQty(c.id, c.qty - 1)} aria-label="Kurangi jumlah">
                        −
                      </button>
                      <span>{c.qty}</span>
                      <button onClick={() => updateQty(c.id, c.qty + 1)} aria-label="Tambah jumlah">
                        +
                      </button>
                    </div>
                    <div className="cart-row-price">{RUPIAH(c.harga * c.qty)}</div>
                    <button className="cart-row-remove" onClick={() => removeFromCart(c.id)} aria-label="Hapus">
                      ✕
                    </button>
                  </li>
                ))}
              </ul>
              <div className="cart-summary">
                <div className="cart-total">
                  <span>Total</span>
                  <strong>{RUPIAH(cartTotal)}</strong>
                </div>
                <a
                  className="btn-primary"
                  target="_blank"
                  rel="noopener noreferrer"
                  href={`https://wa.me/6281234567890?text=${encodeURIComponent(
                    "Halo Air Tenang Koi House, saya mau pesan:\n" +
                      cartDetailed
                        .map((c) => `- ${c.nama} (${c.varietas}, ${c.ukuran}cm) x${c.qty} = ${RUPIAH(c.harga * c.qty)}`)
                        .join("\n") +
                      `\n\nTotal: ${RUPIAH(cartTotal)}`
                  )}`}
                >
                  Pesan via WhatsApp
                </a>
              </div>
            </>
          )}
        </main>
      )}

      {/* ---------- FOOTER ---------- */}
      <footer className="footer">
        <div>
          <strong>Air Tenang Koi House</strong>
          <p>Jl. Kolam Indah No. 8, Blitar, Jawa Timur</p>
        </div>
        <div>
          <p>WhatsApp: 0812-3456-7890</p>
          <p>Buka setiap hari, 08.00–17.00</p>
        </div>
      </footer>

      {/* ---------- PRODUCT DETAIL MODAL ---------- */}
      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelected(null)} aria-label="Tutup">
              ✕
            </button>
            <div className="modal-visual" style={{ color: selected.warna }}>
              <KoiSilhouette className="modal-koi" />
            </div>
            <div className="modal-body">
              <span className="tag">{selected.varietas}</span>
              <h2>{selected.nama}</h2>
              <p className="modal-desc">{selected.deskripsi}</p>
              <dl className="modal-specs">
                <div>
                  <dt>Ukuran</dt>
                  <dd>{selected.ukuran} cm</dd>
                </div>
                <div>
                  <dt>Umur</dt>
                  <dd>{selected.umur}</dd>
                </div>
                <div>
                  <dt>Stok</dt>
                  <dd>{selected.stok} ekor</dd>
                </div>
              </dl>
              <div className="modal-footer">
                <strong className="modal-price">{RUPIAH(selected.harga)}</strong>
                <button
                  className="btn-primary"
                  onClick={() => {
                    addToCart(selected);
                    setSelected(null);
                  }}
                >
                  Tambah ke keranjang
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---------- ADD PRODUCT FORM ---------- */}
      {showAddForm && (
        <AddProductForm
          onClose={() => setShowAddForm(false)}
          onSave={(newProduct) => {
            const withId = { ...newProduct, id: "k-" + Date.now() };
            persistProducts([withId, ...products]);
            setShowAddForm(false);
            showToast(`${newProduct.nama} ditambahkan ke katalog`);
          }}
        />
      )}

      {/* ---------- TOAST ---------- */}
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

// ---------- Product Card ----------
function ProductCard({ p, onOpen, onAdd, onDelete, editable }) {
  return (
    <article className="product-card">
      <button className="product-visual" style={{ color: p.warna }} onClick={onOpen} aria-label={`Lihat detail ${p.nama}`}>
        <KoiSilhouette className="product-koi" />
        {p.stok <= 2 && <span className="stock-flag">Sisa {p.stok}</span>}
      </button>
      <div className="product-info">
        <span className="tag">{p.varietas}</span>
        <h3>
          <button className="product-name-btn" onClick={onOpen}>
            {p.nama}
          </button>
        </h3>
        <p className="product-meta">
          {p.ukuran} cm · {p.umur}
        </p>
        <div className="product-bottom">
          <strong>{RUPIAH(p.harga)}</strong>
          <button className="btn-add" onClick={onAdd}>
            + Keranjang
          </button>
        </div>
        {editable && (
          <button className="product-delete" onClick={onDelete}>
            Hapus dari katalog
          </button>
        )}
      </div>
    </article>
  );
}

// ---------- Add Product Form ----------
function AddProductForm({ onClose, onSave }) {
  const [form, setForm] = useState({
    nama: "",
    varietas: VARIETAS[0],
    ukuran: "",
    umur: "",
    harga: "",
    stok: "",
    deskripsi: "",
    warna: "#D94F30",
  });
  const [error, setError] = useState("");

  const update = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const submit = (e) => {
    e.preventDefault();
    if (!form.nama.trim() || !form.ukuran || !form.harga || !form.stok) {
      setError("Lengkapi nama, ukuran, harga, dan stok terlebih dahulu.");
      return;
    }
    onSave({
      ...form,
      ukuran: Number(form.ukuran),
      harga: Number(form.harga),
      stok: Number(form.stok),
      umur: form.umur.trim() || "Tidak diketahui",
      deskripsi: form.deskripsi.trim() || "Belum ada deskripsi untuk koi ini.",
    });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <form className="modal form-modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <button type="button" className="modal-close" onClick={onClose} aria-label="Tutup">
          ✕
        </button>
        <h2>Tambah koi baru</h2>
        <p className="form-sub">Isi data koi untuk ditampilkan di katalog.</p>

        <label>
          Nama koi
          <input value={form.nama} onChange={(e) => update("nama", e.target.value)} placeholder="contoh: Kohaku Istimewa" />
        </label>

        <div className="form-row">
          <label>
            Varietas
            <select value={form.varietas} onChange={(e) => update("varietas", e.target.value)}>
              {VARIETAS.map((v) => (
                <option key={v}>{v}</option>
              ))}
            </select>
          </label>
          <label>
            Ukuran (cm)
            <input type="number" min="1" value={form.ukuran} onChange={(e) => update("ukuran", e.target.value)} />
          </label>
        </div>

        <div className="form-row">
          <label>
            Umur
            <input value={form.umur} onChange={(e) => update("umur", e.target.value)} placeholder="contoh: 1.5 tahun" />
          </label>
          <label>
            Stok (ekor)
            <input type="number" min="0" value={form.stok} onChange={(e) => update("stok", e.target.value)} />
          </label>
        </div>

        <label>
          Harga (Rp)
          <input type="number" min="0" value={form.harga} onChange={(e) => update("harga", e.target.value)} placeholder="contoh: 2500000" />
        </label>

        <label>
          Deskripsi
          <textarea
            value={form.deskripsi}
            onChange={(e) => update("deskripsi", e.target.value)}
            placeholder="Ceritakan pola, karakter, atau keunikan koi ini…"
            rows={3}
          />
        </label>

        <label>
          Warna aksen kartu
          <input type="color" value={form.warna} onChange={(e) => update("warna", e.target.value)} className="color-input" />
        </label>

        {error && <p className="form-error">{error}</p>}

        <div className="form-actions">
          <button type="button" className="btn-ghost" onClick={onClose}>
            Batal
          </button>
          <button type="submit" className="btn-primary">
            Simpan koi
          </button>
        </div>
      </form>
    </div>
  );
}

// ---------- Styles ----------
const baseStyles = `
:root {
  --ink: #1f2a24;
  --deep: #0E4D4A;
  --teal: #1B7A75;
  --sand: #F4EDE0;
  --white: #FFFFFF;
  --koi-red: #D94F30;
  --brown: #2E2A22;
}
* { box-sizing: border-box; }
body, .app-root { margin: 0; }
.app-root {
  font-family: 'Inter', -apple-system, sans-serif;
  color: var(--brown);
  background: var(--sand);
  min-height: 100vh;
  overflow-x: hidden;
}
.boot-screen {
  height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 14px; background: var(--sand); color: var(--deep); font-family: 'Fraunces', serif; font-size: 1.1rem;
}
.boot-koi { width: 70px; height: 32px; color: var(--teal); animation: swim 1.8s ease-in-out infinite; }
@keyframes swim { 0%,100% { transform: translateX(0) rotate(0deg);} 50% { transform: translateX(10px) rotate(-3deg);} }

h1, h2, h3 { font-family: 'Fraunces', Georgia, serif; color: var(--deep); margin: 0; }

button { font-family: inherit; cursor: pointer; }

/* NAV */
.nav {
  display: flex; align-items: center; justify-content: space-between;
  padding: 18px 6vw; background: var(--white); border-bottom: 1px solid rgba(14,77,74,0.1);
  position: sticky; top: 0; z-index: 30;
}
.brand { display: flex; align-items: center; gap: 10px; background: none; border: none; font-family: 'Fraunces', serif; font-size: 1.25rem; color: var(--deep); }
.brand-icon { width: 36px; height: 16px; color: var(--koi-red); }
.brand small { display: block; font-family: 'Inter', sans-serif; font-size: 0.62rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--teal); font-weight: 600; }
.nav-links { display: flex; align-items: center; gap: 22px; }
.nav-links button { background: none; border: none; font-size: 0.95rem; color: var(--brown); padding: 6px 2px; position: relative; }
.nav-links button.active { color: var(--deep); font-weight: 600; }
.nav-links button.active::after { content: ''; position: absolute; left: 0; right: 0; bottom: -4px; height: 2px; background: var(--koi-red); border-radius: 2px; }
.cart-btn { display: flex; align-items: center; gap: 6px; }
.cart-badge { background: var(--koi-red); color: white; font-size: 0.7rem; font-weight: 700; padding: 1px 7px; border-radius: 999px; }

/* HERO */
.hero { position: relative; padding: 7vw 6vw 6vw; overflow: hidden; min-height: 460px; display: flex; align-items: center; }
.ripple-svg { position: absolute; inset: 0; width: 100%; height: 100%; z-index: 0; }
.hero-koi { position: absolute; z-index: 1; opacity: 0.9; }
.hero-koi-1 { width: 130px; height: 58px; color: var(--koi-red); top: 18%; right: 12%; animation: swim 5s ease-in-out infinite; }
.hero-koi-2 { width: 90px; height: 40px; color: var(--deep); top: 58%; right: 26%; opacity: 0.5; animation: swim 6.5s ease-in-out infinite reverse; }
.hero-content { position: relative; z-index: 2; max-width: 620px; }
.eyebrow { display: inline-block; font-size: 0.78rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--teal); font-weight: 700; margin-bottom: 14px; }
.hero h1 { font-size: clamp(2.4rem, 5.5vw, 4.2rem); line-height: 1.04; font-weight: 600; }
.hero p { font-size: 1.08rem; line-height: 1.6; margin: 22px 0 30px; max-width: 480px; color: var(--brown); }
.hero-actions { display: flex; gap: 16px; align-items: center; }

.btn-primary { background: var(--koi-red); color: white; border: none; padding: 13px 26px; border-radius: 999px; font-size: 0.95rem; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; transition: transform 0.15s ease, background 0.2s; }
.btn-primary:hover { background: #c2421f; transform: translateY(-1px); }
.btn-primary.small { padding: 10px 18px; font-size: 0.88rem; white-space: nowrap; }
.btn-ghost { color: var(--deep); text-decoration: none; font-weight: 600; padding: 13px 8px; border-bottom: 1px solid var(--deep); }

/* STRIP */
.strip { display: flex; justify-content: center; gap: 60px; padding: 30px 6vw 50px; flex-wrap: wrap; border-bottom: 1px solid rgba(14,77,74,0.12); }
.strip-item { display: flex; flex-direction: column; align-items: center; text-align: center; }
.strip-item strong { font-family: 'Fraunces', serif; font-size: 2rem; color: var(--deep); }
.strip-item span { font-size: 0.82rem; color: var(--teal); margin-top: 2px; }

/* FEATURED / SECTIONS */
.featured, .catalog-page, .cart-page, .how { padding: 60px 6vw; max-width: 1240px; margin: 0 auto; }
.section-head { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 30px; }
.section-head h2 { font-size: 1.9rem; }
.link-btn { background: none; border: none; color: var(--koi-red); font-weight: 600; font-size: 0.9rem; }

.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 26px; }

.product-card { background: var(--white); border-radius: 28px; overflow: hidden; box-shadow: 0 8px 24px rgba(14,77,74,0.07); display: flex; flex-direction: column; }
.product-visual { border: none; background: radial-gradient(circle at 30% 30%, rgba(27,122,117,0.12), rgba(244,237,224,0.4)); padding: 0; height: 140px; position: relative; display: flex; align-items: center; justify-content: center; }
.product-koi { width: 65%; height: auto; }
.stock-flag { position: absolute; top: 12px; right: 12px; background: var(--koi-red); color: white; font-size: 0.7rem; font-weight: 700; padding: 3px 10px; border-radius: 999px; }
.product-info { padding: 18px 20px 20px; display: flex; flex-direction: column; gap: 6px; }
.tag { align-self: flex-start; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em; color: var(--teal); font-weight: 700; background: rgba(27,122,117,0.1); padding: 3px 10px; border-radius: 999px; }
.product-name-btn { background: none; border: none; padding: 0; font-family: 'Fraunces', serif; font-size: 1.2rem; color: var(--deep); text-align: left; }
.product-meta { font-size: 0.85rem; color: #5b5347; margin: 0; }
.product-bottom { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; }
.product-bottom strong { font-family: 'Fraunces', serif; color: var(--deep); font-size: 1.05rem; }
.btn-add { background: var(--deep); color: white; border: none; padding: 8px 14px; border-radius: 999px; font-size: 0.8rem; font-weight: 600; }
.product-delete { margin-top: 6px; background: none; border: none; color: #a84a3a; font-size: 0.76rem; text-decoration: underline; padding: 0; align-self: flex-start; }

/* HOW */
.how h2 { font-size: 1.9rem; margin-bottom: 30px; }
.how ol { list-style: none; padding: 0; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap: 24px; }
.how li { background: var(--white); border-radius: 20px; padding: 22px 20px; font-size: 0.92rem; line-height: 1.5; box-shadow: 0 6px 18px rgba(14,77,74,0.06); }
.how-mark { display: block; font-family: 'Fraunces', serif; color: var(--koi-red); font-size: 1.15rem; margin-bottom: 8px; }

/* CATALOG */
.catalog-head h1 { font-size: 2.4rem; }
.catalog-head p { color: var(--teal); margin-top: 6px; }
.catalog-toolbar { display: flex; gap: 12px; flex-wrap: wrap; margin: 28px 0 32px; }
.search-input { flex: 1; min-width: 180px; }
.catalog-toolbar input, .catalog-toolbar select {
  padding: 11px 14px; border-radius: 12px; border: 1px solid rgba(14,77,74,0.2); background: var(--white); font-size: 0.92rem; color: var(--brown);
}

/* EMPTY STATE */
.empty-state { text-align: center; padding: 60px 20px; display: flex; flex-direction: column; align-items: center; gap: 10px; }
.empty-koi { width: 100px; height: 45px; color: var(--teal); opacity: 0.5; margin-bottom: 10px; }
.empty-state h3 { font-size: 1.3rem; }
.empty-state p { color: #6b6357; margin: 0 0 10px; }

/* CART */
.cart-page h1 { font-size: 2.2rem; margin-bottom: 30px; }
.cart-list { list-style: none; padding: 0; display: flex; flex-direction: column; gap: 14px; }
.cart-row { display: grid; grid-template-columns: 60px 1fr auto auto 30px; align-items: center; gap: 16px; background: var(--white); border-radius: 18px; padding: 14px 18px; box-shadow: 0 4px 14px rgba(14,77,74,0.06); }
.cart-row-koi { width: 50px; height: 24px; }
.cart-koi-icon { width: 100%; height: 100%; }
.cart-row-info { display: flex; flex-direction: column; }
.cart-row-info strong { font-family: 'Fraunces', serif; color: var(--deep); }
.cart-row-info span { font-size: 0.82rem; color: #6b6357; }
.cart-row-qty { display: flex; align-items: center; gap: 10px; }
.cart-row-qty button { width: 28px; height: 28px; border-radius: 50%; border: 1px solid rgba(14,77,74,0.25); background: var(--sand); font-size: 1rem; }
.cart-row-price { font-weight: 700; color: var(--deep); white-space: nowrap; }
.cart-row-remove { background: none; border: none; color: #a84a3a; font-size: 1rem; }
.cart-summary { display: flex; justify-content: space-between; align-items: center; margin-top: 36px; padding-top: 24px; border-top: 1px solid rgba(14,77,74,0.15); flex-wrap: wrap; gap: 18px; }
.cart-total { display: flex; flex-direction: column; }
.cart-total span { font-size: 0.85rem; color: var(--teal); }
.cart-total strong { font-family: 'Fraunces', serif; font-size: 1.8rem; color: var(--deep); }

/* FOOTER */
.footer { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 20px; padding: 40px 6vw; background: var(--deep); color: #d9ece9; }
.footer strong { color: white; font-family: 'Fraunces', serif; font-size: 1.1rem; }
.footer p { color: #bcdedb; font-size: 0.88rem; margin: 4px 0 0; }

/* MODAL */
.modal-overlay { position: fixed; inset: 0; background: rgba(14,30,27,0.55); display: flex; align-items: center; justify-content: center; z-index: 100; padding: 20px; backdrop-filter: blur(2px); }
.modal { background: var(--white); border-radius: 28px; max-width: 560px; width: 100%; max-height: 90vh; overflow-y: auto; position: relative; display: flex; flex-direction: column; }
.modal-close { position: absolute; top: 16px; right: 16px; background: rgba(14,77,74,0.08); border: none; width: 32px; height: 32px; border-radius: 50%; font-size: 0.9rem; z-index: 2; }
.modal-visual { background: radial-gradient(circle at 30% 30%, rgba(27,122,117,0.15), transparent); padding: 36px; display: flex; justify-content: center; }
.modal-koi { width: 50%; }
.modal-body { padding: 0 32px 32px; }
.modal-body h2 { font-size: 1.7rem; margin: 10px 0 12px; }
.modal-desc { color: #5b5347; line-height: 1.6; margin: 0 0 20px; }
.modal-specs { display: flex; gap: 28px; margin: 0 0 24px; }
.modal-specs dt { font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.06em; color: var(--teal); margin-bottom: 3px; }
.modal-specs dd { margin: 0; font-weight: 700; color: var(--deep); }
.modal-footer { display: flex; justify-content: space-between; align-items: center; padding-top: 18px; border-top: 1px solid rgba(14,77,74,0.12); }
.modal-price { font-family: 'Fraunces', serif; font-size: 1.5rem; color: var(--deep); }

/* FORM MODAL */
.form-modal { padding: 32px; gap: 14px; display: flex; flex-direction: column; }
.form-modal h2 { font-size: 1.5rem; }
.form-sub { color: #6b6357; margin: -8px 0 6px; font-size: 0.88rem; }
.form-modal label { display: flex; flex-direction: column; gap: 6px; font-size: 0.85rem; font-weight: 600; color: var(--deep); }
.form-modal input, .form-modal select, .form-modal textarea {
  font-family: inherit; padding: 10px 12px; border-radius: 10px; border: 1px solid rgba(14,77,74,0.25); font-size: 0.92rem; color: var(--brown); font-weight: 400; background: var(--sand);
}
.color-input { padding: 4px; height: 40px; cursor: pointer; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.form-error { color: #a84a3a; font-size: 0.85rem; margin: 0; }
.form-actions { display: flex; justify-content: flex-end; gap: 12px; margin-top: 8px; }

/* TOAST */
.toast { position: fixed; bottom: 28px; left: 50%; transform: translateX(-50%); background: var(--deep); color: white; padding: 12px 22px; border-radius: 999px; font-size: 0.88rem; z-index: 200; box-shadow: 0 8px 24px rgba(0,0,0,0.2); animation: rise 0.25s ease; }
@keyframes rise { from { opacity: 0; transform: translate(-50%, 10px); } to { opacity: 1; transform: translate(-50%, 0); } }

/* RESPONSIVE */
@media (max-width: 720px) {
  .nav { padding: 14px 5vw; }
  .nav-links { gap: 12px; }
  .hero { padding: 14vw 6vw 10vw; }
  .hero-koi { display: none; }
  .form-row { grid-template-columns: 1fr; }
  .cart-row { grid-template-columns: 40px 1fr; grid-template-areas: "icon info" "qty price" ". remove"; row-gap: 8px; }
  .cart-row-qty { grid-area: qty; }
  .cart-row-price { grid-area: price; text-align: right; }
  .cart-row-remove { grid-area: remove; justify-self: end; }
  .footer { flex-direction: column; }
}

@media (prefers-reduced-motion: reduce) {
  .hero-koi, .boot-koi { animation: none !important; }
}

button:focus-visible, input:focus-visible, select:focus-visible, textarea:focus-visible, a:focus-visible {
  outline: 2px solid var(--koi-red); outline-offset: 2px;
}

@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400..700&family=Inter:wght@400;500;600;700&display=swap');
`;
